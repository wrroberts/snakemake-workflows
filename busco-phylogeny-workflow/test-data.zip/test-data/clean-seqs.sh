#!/bin/bash

for i in */
do
	cd "$i"
	for j in *.faa
		do
		awk "/^>/ {n++} n>1 {exit} 1" $j > $j.faa2
		sed -i "s|>|>$i |g" $j.faa2
		sed -i "s|/||g" $j.faa2
		cut -d ' ' -f1 $j.faa2 > $j.faa2.cut
		sed -i "s|*||g" $j.faa2.cut
		mv $j.faa2.cut $j
		rm $j.faa2
	done
	cd ..
done

for i in `cat busco-seqs.txt`
do
	cat */$i >> $i
done

mkdir prot-seqs 
mv *.faa prot-seqs/

